from app import app
from flask import render_template
from flask import Response
import os,time,requests,json
from qpylib import qpylib
from app.qpylib.qpylib import get_app_id, get_console_address, get_store_path, log, is_sdk, strategy
from qpylib.offense_qpylib import get_offense_json_html
flowSeries2Render = []
globalOffenseId = 0
#this is interval in milliseconds to group values in the AQL query
#in an ideal world, this would be adaptive from the query in order to avoid getting something too big
intervalQuery = 1000
timeZone = 3600*2*intervalQuery

#SUM(sourcebytes), SUM(destinationbytes),
def highchartifyDataFlow(elements,serieName):
    # formatting for HighCharts container format, thanks to the logsourceApp
    series = []
    counter = []
    myData =  []
    log('in flow format')
    previousTimeStamp=0
    valueToAdd=0
    myAxisIndex=3
    for element in elements:
        if serieName == 'sumSrc':
            valueToAdd=float(element.get('sumSrc'))
        if serieName == 'sumDst':
            valueToAdd=float(element.get('sumDst'))
        myTimeStamp=int(element.get('hour'))
        gapBetween2Measures = myTimeStamp-previousTimeStamp
        if gapBetween2Measures > 1 and previousTimeStamp > 0:
            dateToInsert=int((int(previousTimeStamp)*int(intervalQuery))+timeZone+1000)
            series.append(dateToInsert)
            series.append(float(0))
            counter.append(series)
            series = []
            dateToInsert=int((int(myTimeStamp)*int(intervalQuery))+timeZone-1000)
            series.append(dateToInsert)
            series.append(float(0))
            counter.append(series)
            series = []
        series.append(int(element.get('hour'))*int(intervalQuery)+timeZone)
        series.append(valueToAdd)
        counter.append(series)
        series = []
        previousTimeStamp=myTimeStamp
    myType='area'
    if serieName == 'sumSrc':
        myAxisIndex = 3
        myType = 'line'
    if serieName == 'sumDst':
        myAxisIndex = 4
        myType = 'line'
    myData.append({'name':serieName,'yAxis':myAxisIndex,'data':counter,'type':myType})
    return myData


def highchartifyData(elements,serieName):
    # formatting for HighCharts container format, thanks to the logsourceApp
    series = []
    counter = []
    myData =  []
    previousTimeStamp=0
    for element in elements:
        countToAdd=float(element.get('myCount'))
        myTimeStamp=int(element.get('hour'))
        gapBetween2Measures = myTimeStamp-previousTimeStamp
        if gapBetween2Measures > 1 and previousTimeStamp > 0:
            dateToInsert=int((int(previousTimeStamp)*int(intervalQuery))+timeZone+1000)
            series.append(dateToInsert)
            series.append(float(0))
            counter.append(series)
            series = []
            dateToInsert=int((int(myTimeStamp)*int(intervalQuery))+timeZone-1000)
            series.append(dateToInsert)
            series.append(float(0))
            counter.append(series)
            series = []
        series.append(int(element.get('hour'))*int(intervalQuery)+timeZone)
        series.append(countToAdd)
        counter.append(series)
        series = []
        previousTimeStamp=myTimeStamp
    if serieName == 'alerts':
        myAxisIndex = 0
        myType2 = 'spline'
    if serieName == 'events':
        myAxisIndex = 1
        myType2 = 'column'
    if serieName == 'flows':
        myAxisIndex = 2
        myType2 = 'column'
    myData.append({'name':serieName,'yAxis':myAxisIndex,'data':counter,'type':myType2})
    return myData

def getElementsFromOffense(offense_id,offenseStartTime,offenseEndTime,myDatabase):
    try:
        headers = {'content_type':'application/json', 'Version':'7.0'}
        whereClause = 'INOFFENSE('+str(offense_id)+')'
        if myDatabase == 'events' :
            whereClause = whereClause+' AND NOT(logsourceid=63)'
        if myDatabase == 'alerts' :
            myDatabase = 'events'
            whereClause = whereClause+' AND logsourceid=63'
        preQuery1 = "select starttime/"+str(intervalQuery)+" as hour, count(*) as myCount"
        log(preQuery1)
        if myDatabase == 'flows' :
                preQuery1+=',SUM(sourcebytes) as sumSrc, SUM(destinationbytes) as sumDst'
        preQuery2 = " from "+myDatabase+" where "+whereClause+" group by hour order by hour START "+str(offenseStartTime)+" STOP "+str(offenseEndTime)+""
        preQuery = preQuery1+preQuery2
        log(preQuery)
        query = {'query_expression':preQuery}
        response=qpylib.REST('POST','/api/ariel/searches', headers=headers, params=query)
        responseJson=response.json()
        searchID = responseJson['search_id']
        log('Info search id '+searchID)
        headers = {'content_type':'application/json','Accept':'application/json', 'Version':'7.0'}
        while True:
            time.sleep(0.3)
            response=qpylib.REST('GET','/api/ariel/searches/' + searchID , headers=headers)
            responseJson = response.json()
            if responseJson['status'] == "COMPLETED":
                break
        flowCount = responseJson['record_count']
        headers = {'content_type':'application/json','Accept':'application/json', 'Version':'7.0'}
        response=qpylib.REST('get','/api/ariel/searches/' + searchID +'/results', headers=headers)
        return response.json().get(myDatabase)
    except Exception as e:
            qpylib.log("Error Ex " + str(e),level='error')
            raise
        
def getCategoriesFromOffense(offense_id,offenseStartTime,offenseEndTime,myDatabase):
    try:
        # select CATEGORYNAME(category) as LLC, count(*) as myCount from events where INOFFENSE(2185) GROUP BY LLC ORDER BY myCount last 7 DAYS       
        headers = {'content_type':'application/json', 'Version':'7.0'}
        whereClause = 'INOFFENSE('+str(offense_id)+')'
        preQuery = "select CATEGORYNAME(category) as LLC, count(*) as myCount from "+myDatabase+" where "+whereClause+" GROUP BY LLC ORDER BY myCount START "+str(offenseStartTime)+" STOP "+str(offenseEndTime)+""
        query = {'query_expression':preQuery}
        response=qpylib.REST('POST','/api/ariel/searches', headers=headers, params=query)
        responseJson=response.json()
        searchID = responseJson['search_id']
        log('Info search id '+searchID)
        headers = {'content_type':'application/json','Accept':'application/json', 'Version':'7.0'}
        while True:
            response=qpylib.REST('GET','/api/ariel/searches/' + searchID , headers=headers)
            responseJson = response.json()
            if responseJson['status'] == "COMPLETED":
                break
        flowCount = responseJson['record_count']
        headers = {'content_type':'application/json','Accept':'application/json', 'Version':'7.0'}
        response=qpylib.REST('get','/api/ariel/searches/' + searchID +'/results', headers=headers)
        return response.json().get(myDatabase)
    except Exception as e:
            qpylib.log("Error categories " + str(e),level='error')
            raise

@app.route('/')
@app.route('/index/<offenseID2Render>')
def index(offenseID2Render):
    try:
        app_id = get_app_id()
        headers = {'content_type':'application/json', 'Version':'7.0'}
        response1=qpylib.REST('GET','/api/siem/offenses/' + offenseID2Render +'?fields=start_time%2Clast_updated_time', headers=headers)
        responseJson = response1.json()
        offenseStartTime = responseJson['start_time']
        offenseEndTime = responseJson['last_updated_time']
        app_url = '/console/plugins/{app_id}/app_proxy'.format(app_id=app_id)
        alertSeries = getElementsFromOffense(int(offenseID2Render),int(offenseStartTime),int(offenseEndTime),'alerts')
        alertSeries2Render =  highchartifyData(alertSeries,'alerts')
        eventSeries = getElementsFromOffense(int(offenseID2Render),int(offenseStartTime),int(offenseEndTime),'events')
        eventSeries2Render =  highchartifyData(eventSeries,'events')
        flowSeries = getElementsFromOffense(int(offenseID2Render),int(offenseStartTime),int(offenseEndTime),'flows')
        flowSeries2Render =  highchartifyData(flowSeries,'flows')
        #sumSrcSeries = getElementsFromOffense(int(offenseID2Render),int(offenseStartTime),int(offenseEndTime),'sumSrc')
        #log(str(flowSeries))
        sumSrcSeries2Render =  highchartifyDataFlow(flowSeries,'sumSrc')
        #sumDstSeries = getElementsFromOffense(int(offenseID2Render),int(offenseStartTime),int(offenseEndTime),'destSrc')
        sumDstSeries2Render =  highchartifyDataFlow(flowSeries,'sumDst')
        series=alertSeries2Render+eventSeries2Render+flowSeries2Render+sumSrcSeries2Render+sumDstSeries2Render
        return render_template('fragmentview.html', title = "Relevant Datas Stream", series=series)
    except Exception as b:
        log('Error OffenseID2Render ' + str(b))
        raise

@app.route('/fragoffense/<offense_id>', methods=['GET'])
def get_offense(offense_id):
  try:
      offense_json = get_offense_json_html(offense_id, custom_html_generator)
      return Response(response=offense_json, status=200, mimetype='application/json')
  except Exception as b:
        log('Error ExGetOffense ' + str(b))
        raise

def custom_html_generator(offense_json):
    myOffenseID = str(offense_json['id'])
    app_id = get_app_id()
    app_url = '/console/plugins/{app_id}/app_proxy'.format(app_id=app_id)
    url2return = '<iframe height="195px" min-height="150px" width="100%" frameBorder="0" ' +'scrolling="no"  src="' + app_url +'/index/'+str(myOffenseID)+ '"></iframe>'
    return (url2return)