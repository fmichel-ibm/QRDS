import __builtin__
import qpylib
__author__ = 'IBM'
__version__ = '0.10+9507639f6b9fe978665b2667214df449eee1a02b'

__builtin__.get_app_base_url = qpylib.get_app_base_url
__builtin__.q_url_for = qpylib.q_url_for
